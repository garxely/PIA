<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reseñas por Año</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <header>
        <h1>Reseñas por Año</h1>
        <?php
        if (isset($_GET['years']) && !empty($_GET['years'])) {
            $years = $_GET['years'];
            include 'db.php';  
            foreach ($years as $year) {
                echo "<h2>Año: $year</h2>";

                $sql = "SELECT * FROM Reseñas WHERE Año = " . intval($year);
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<p>" . $row["Reseña"] . "</p>";
                    }
                } else {
                    echo "<p>No hay reseñas para este año.</p>";
                }
            }

            $conn->close();
        } else {
            echo "<p>No se seleccionaron años.</p>";
        }
        ?>
    </header>
</div>

</body>
</html>
