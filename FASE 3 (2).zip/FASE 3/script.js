function showScreen(screen) {
    window.location.href = screen + ".html";
}

function publishReview() {
    alert("Reseña publicada");
}
