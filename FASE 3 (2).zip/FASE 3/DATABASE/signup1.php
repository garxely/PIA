<?php
include 'db.php';  

$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$nickname = $_POST['nickname'];


if (empty($email) || empty($password) || empty($phone) || empty($nickname)) {
    die("Todos los campos son obligatorios.");
}

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO Usuario (correo, contraseña, numeroTelefonico, Apodo, idRol) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);


$stmt->bind_param("ssssi", $email, $hashed_password, $phone, $nickname, $idRol);

if ($stmt->execute()) {
    echo "Usuario registrado exitosamente.";
    header("Location: login.html"); 
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
