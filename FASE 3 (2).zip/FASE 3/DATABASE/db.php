<?php
$servername = "localhost";
$username = "ely.mgarcia1406@gmail.com"; 
$password = "BJAlex";  
$dbname = "script1.0"; 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
