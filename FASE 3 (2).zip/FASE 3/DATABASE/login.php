<?php
include 'db.php';  


$email = $_POST['email'];
$password = $_POST['password'];


if (empty($email) || empty($password)) {
    die("Correo electrónico y contraseña son obligatorios.");
}

$sql = "SELECT idUsuario, contraseña FROM Usuario WHERE correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($idUsuario, $hashed_password);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
        echo "Inicio de sesión exitoso.";
        header("Location: menu.html"); .
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "No se encontró un usuario con ese correo electrónico.";
}

$stmt->close();
$conn->close();
?>
