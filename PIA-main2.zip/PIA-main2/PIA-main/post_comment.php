<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $comentario = $_POST['comentario'];

    $sql = "INSERT INTO comentarios (usuario, comentario) VALUES ('$usuario', '$comentario')";

    if ($conn->query($sql) === TRUE) {
        echo "Comentario publicado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
