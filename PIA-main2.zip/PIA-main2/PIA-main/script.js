function showScreen(screen) {
    window.location.href = screen + ".html";
}

function publishReview() {
    alert("Reseña publicada");
    // Aquí podrías enviar la reseña al servidor mediante AJAX
}
