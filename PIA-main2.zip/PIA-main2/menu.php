<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Incluir el archivo header.php -->
    <?php include 'header.php'; ?>
    
    <div class="container">
        <h1 class="text-center mt-5">Menú</h1>
        <div class="buttons text-center mt-5">
            <button onclick="window.location.href='movie.php'" class="btn btn-primary">Película</button>
            <button onclick="window.location.href='game.php'" class="btn btn-primary">Juego</button>
            <button onclick="window.location.href='song.php'" class="btn btn-primary">Canción</button>
            <button onclick="window.location.href='añospasadosganadores.php'" class="btn btn-primary">Años Pasados</button>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
