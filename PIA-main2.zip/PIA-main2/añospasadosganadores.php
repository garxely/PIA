<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Movies, Games, Songs</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
	<!-- Incluir el archivo header.html -->
    <?php include 'header.html'; ?>
	
	<div class="container">
	  <header>
		<h1>Movies, Games, Songs</h1>
	  </header>
	  <div class="section">
		<div class="item">
		  <img src="movie_image.jpg" alt="Movie">
		  <p class="title"><a href="individual.html">Movie Title</a></p>
		</div>
		<div class="item">
		  <img src="game_image.jpg" alt="Game">
		  <p class="title"><a href="individual.html">Game Title</a></p>
		</div>
		<div class="item">
		  <img src="song_image.jpg" alt="Song">
		  <p class="title"><a href="individual.html">Song Title</a></p>
		</div>
	  </div>
	</div>
</body>
</html>
