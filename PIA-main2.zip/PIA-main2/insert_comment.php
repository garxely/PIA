<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_SESSION['usuario'];
    $comentario = $_POST['comentario'];
    $tipo = $_POST['tipo'];

    if (!empty($usuario) && !empty($comentario) && !empty($tipo)) {
        $sql = "INSERT INTO comentarios (usuario, comentario, tipo) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $usuario, $comentario, $tipo);

        if ($stmt->execute()) {
            echo "Comentario insertado correctamente";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Todos los campos son obligatorios";
    }

    $conn->close();
}
?>
