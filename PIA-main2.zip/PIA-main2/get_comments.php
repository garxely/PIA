<?php
/*include 'db.php';

$sql = "SELECT usuario, comentario FROM comentarios";
$result = $conn->query($sql);

$comments = array();

while($row = $result->fetch_assoc()) {
    $comments[] = $row;
}

echo json_encode($comments);

$conn->close();
*/
	session_start();
include 'db.php';

if (isset($_SESSION['usuario'])) {
    $usuario = $_SESSION['usuario'];

    $result = $conn->query("SELECT comentario, tipo FROM comentarios WHERE usuario='$usuario'");

    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }

    echo json_encode($comments);
} else {
    echo json_encode([]);
}

$conn->close();
?>
