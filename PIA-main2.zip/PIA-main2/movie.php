<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Película</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <h1 class="title">Película</h1>
        <div class="content">
            <div class="container">
                <img src="opp.jpg" alt="Imagen de la película" class="movie-image">
            </div>
            <div class="review">
                <form id="comment-form">
                    <textarea name="comentario" placeholder="Escribe tu reseña aquí"></textarea>
                    <input type="hidden" name="usuario" value="<?php echo $_SESSION['usuario']; ?>"> <!-- Usa el nombre de usuario real -->
                    <input type="hidden" name="tipo" value="movie">
                    <button type="submit" class="btn btn-primary">Publicar</button>
                </form>
            </div>
            <div class="details">
                <h2>Oppenheimer</h2>
                <p>Durante la Segunda Guerra Mundial, el teniente general Leslie Groves designa al físico J. Robert Oppenheimer para un grupo de trabajo que está desarrollando el Proyecto Manhattan, cuyo objetivo consiste en fabricar la primera bomba atómica.</p>
                <h3>Reparto:</h3>
                <ul>
                    <li>Cillian Murphy</li>
                    <li>Emily Blunt</li>
                    <li>Robert Downey Jr</li>
                </ul>
            </div>
            <button onclick="window.location.href='menu.php'" class="btn btn-secondary">Regresar</button>
        </div>
        <div class="comments">
            <h2>Comentarios</h2>
            <?php
            include 'db.php';
            try {
                // Consulta los comentarios de la base de datos
                $result = $conn->query("SELECT usuario, comentario FROM comentarios WHERE tipo='movie'");

                if (!$result) {
                    throw new Exception("Error en la consulta: " . $conn->error);
                }

                // Muestra los comentarios
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='comment'>";
                    echo "<span class='username'>" . htmlspecialchars($row['usuario']) . ":</span>";
                    echo "<p>" . htmlspecialchars($row['comentario']) . "</p>";
                    echo "</div>";
                }
            } catch (Exception $e) {
                echo "<p>Error: " . $e->getMessage() . "</p>";
            } finally {
                $conn->close();
            }
            ?>
        </div>
    </div>

    <script>
        document.getElementById('comment-form').addEventListener('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(event.target);
            fetch('insert_comment.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                if (data.includes('Comentario insertado correctamente')) {
                    window.location.reload();
                }
            })
            .catch(error => console.error('Error:', error));
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
