<?php
include 'db.php';

$usuarios = [
    ['email' => 'usuario1@example.com', 'password' => 'password1', 'telefono' => '1234567890', 'apodo' => 'usuario1'],
    ['email' => 'usuario2@example.com', 'password' => 'password2', 'telefono' => '0987654321', 'apodo' => 'usuario2'],
    ['email' => 'usuario3@example.com', 'password' => 'password3', 'telefono' => '1122334455', 'apodo' => 'usuario3']
];

foreach ($usuarios as $usuario) {
    $email = $usuario['email'];
    $password = password_hash($usuario['password'], PASSWORD_BCRYPT);
    $telefono = $usuario['telefono'];
    $apodo = $usuario['apodo'];

    $sql = "INSERT INTO usuarios (email, password, telefono, apodo) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $email, $password, $telefono, $apodo);

    if ($stmt->execute()) {
        echo "Usuario $email creado exitosamente\n";
    } else {
        echo "Error: " . $stmt->error . "\n";
    }

    $stmt->close();
}

$conn->close();
?>
