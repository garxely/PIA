<?php
session_start();
include 'db.php';

if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit();
}

$usuario = $_SESSION['usuario'];
$query = "SELECT apodo FROM usuarios WHERE email='$usuario'";
$result = $conn->query($query);
$apodo = '';

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $apodo = $row['apodo'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <header>
            <h1>Perfil de Usuario</h1>
        </header>
        <div class="profile-info">
            <h2>Apodo: <span id="nickname"><?php echo htmlspecialchars($apodo); ?></span></h2>
            <h3>Email: <span id="email"><?php echo htmlspecialchars($usuario); ?></span></h3>
        </div>
        <div class="reviews-section">
            <br><h2>Reseñas Realizadas</h2>
            <br><h3>Comentarios en canciones</h3>
            <ul id="song-comments" class="comments-list"></ul>
            <br><h3>Comentarios en películas</h3>
            <ul id="movie-comments" class="comments-list"></ul>
            <br><h3>Comentarios en juegos</h3>
            <ul id="game-comments" class="comments-list"></ul>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            fetch('get_comments.php')
            .then(response => response.json())
            .then(data => {
                const songComments = document.getElementById('song-comments');
                const movieComments = document.getElementById('movie-comments');
                const gameComments = document.getElementById('game-comments');

                data.forEach(comment => {
                    const commentElement = document.createElement('li');
                    commentElement.textContent = comment.comentario;
                    if (comment.tipo === 'song') {
                        songComments.appendChild(commentElement);
                    } else if (comment.tipo === 'movie') {
                        movieComments.appendChild(commentElement);
                    } else if (comment.tipo === 'game') {
                        gameComments.appendChild(commentElement);
                    }
                });
            })
            .catch(error => console.error('Error:', error));
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
